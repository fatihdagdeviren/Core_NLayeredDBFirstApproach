﻿using AspNetCoreNLayerDbFirst.API.Dtos;
using AspNetCoreNLayerDbFirst.Core.Entities.Concrete;
using AspNetCoreNLayerDbFirst.Core.Repositories.Dapper;
using AspNetCoreNLayerDbFirst.Core.Services.Dapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Configuration;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace AspNetCoreNLayerDbFirst.API.Filters
{
    public class AuthFilter : ActionFilterAttribute, IActionFilter
    {
        public IUserDapperService _userService;
        private IConfiguration _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;


        public AuthFilter(IUserDapperService userService, IConfiguration configuration, IHttpContextAccessor httpContextAccessor)
        {
            _userService = userService;
            _configuration = configuration;
            _httpContextAccessor = httpContextAccessor;
        }
        public async override Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            var url = _configuration["UnipaMaster:Url"];
            int mode = Convert.ToInt32(_configuration["UnipaMaster:Mode"]);

            string authNo = _httpContextAccessor.HttpContext.Request.Query["OturumNo"].ToString();
            int appId = (mode == 2) ? 10050801 : 10041401;

            if (authNo != string.Empty)
            {
                string dbExt = _configuration.GetSection("UnipaMaster:ConnectionString").ToString().ToLower().Contains("test") ? "_Test" : "";
                string query = $@"select k.KullaniciID,k.KullaniciAdi,k.AdSoyad,k.Aktif,ok.OturumNo from UnipamasterDB{dbExt}..Kullanici k
                        INNER JOIN UnipamasterDB{dbExt}..KullaniciYetki ky on ky.KullaniciID = k.KullaniciID and ky.UygulamaID = {appId} and YetkiID = 'uygulama'
                        INNER JOIN UnipamasterDB{dbExt}..OturumKayit ok on ok.KullaniciID collate SQL_Latin1_General_CP1254_CI_AS = k.KullaniciID 
                        where ok.OturumNo = '{ authNo }' and ok.OturumTarihi > DATEADD(MINUTE, -5760, GETDATE())";
                var u = _userService.QuerySingle(query);
                if (u != null)
                {
                    await next();
                    }
                else
                {
                    ErrorDto errorDTO = new ErrorDto();
                    errorDTO.Status = 404;
                    errorDTO.Errors.Add("User not found");
                    context.Result = new NotFoundObjectResult(errorDTO);
                }
            }
            else
            {
                ErrorDto errorDTO = new ErrorDto();
                errorDTO.Status = 401;
                errorDTO.Errors.Add("Not authorized");
                context.Result = new UnauthorizedObjectResult(errorDTO);
            }
        }
    }
}
