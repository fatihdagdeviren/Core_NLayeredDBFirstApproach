﻿using AspNetCoreNLayerDbFirst.API.Filters;
using AspNetCoreNLayerDbFirst.Business.Services.Redis;
using AspNetCoreNLayerDbFirst.Core.Entities.Concrete;
using AspNetCoreNLayerDbFirst.Core.Services.EntityFramework;
using AspNetCoreNLayerDbFirst.Data.Repositories.EntityFramework.Contexts;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using StackExchange.Redis;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AspNetCoreNLayerDbFirst.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ServiceFilter(typeof(AuthFilter))]
    public class CategoriesController : ControllerBase
    {
        private readonly ICategoryEntityService _categoryService;
        private readonly IMapper _mapper;
        private readonly EntityDbContext _context;

        private readonly RedisService _redisService;
        private readonly IDatabase _db;
        private readonly string _redisKey = "categories";


        public CategoriesController(EntityDbContext context, ICategoryEntityService categoryService, IMapper mapper, RedisService redisService)
        {
            _context = context;
            _categoryService = categoryService;
            _mapper = mapper;
            _redisService = redisService;
            _db = _redisService.GetDb(0);
        }

        // GET: api/Categories
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Category>>> GetCategories()
        {
            return await _context.Categories.ToListAsync();
        }

        // GET: api/Categories/5
        [HttpGet("{id}")]
        [ServiceFilter(typeof(NotFoundFilter))]
        public async Task<ActionResult<Category>> GetCategory(int id)
        {
            var category = await _context.Categories.FindAsync(id);

            if (category == null)
            {
                return NotFound();
            }

            return category;
        }

        // PUT: api/Categories/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCategory(int id, Category category)
        {
            if (id != category.Id)
            {
                return BadRequest();
            }

            var currentCategory = await _context.Categories.FindAsync(id);
            string jsonOld = JsonConvert.SerializeObject(currentCategory);
            await _db.ListRemoveAsync(_redisKey, jsonOld);

            try
            {
                string json = JsonConvert.SerializeObject(category);
                await _db.ListRightPushAsync(_redisKey, json);

                currentCategory.Id = category.Id;
                currentCategory.Name = category.Name;
                currentCategory.IsDeleted = category.IsDeleted;

                _context.Update<Category>(currentCategory);

                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CategoryExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return NoContent();
        }

        // POST: api/Categories
        [HttpPost]
        public async Task<ActionResult<Category>> PostCategory(Category category)
        {

            _context.Categories.Add(category);
            await _context.SaveChangesAsync();

            string json = JsonConvert.SerializeObject(category);
            await _db.ListRightPushAsync(_redisKey, json);

            return CreatedAtAction("GetCategory", new { id = category.Id }, category);
        }

        // DELETE: api/Categories/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Category>> DeleteCategory(int id)
        {
            var category = await _context.Categories.FindAsync(id);
            if (category == null)
            {
                return NotFound();
            }

            _context.Categories.Remove(category);
            await _context.SaveChangesAsync();

            string json = JsonConvert.SerializeObject(category);
            await _db.ListRemoveAsync(_redisKey, json);

            return category;
        }

        private bool CategoryExists(int id)
        {
            return _context.Categories.Any(e => e.Id == id);
        }
    }
}
