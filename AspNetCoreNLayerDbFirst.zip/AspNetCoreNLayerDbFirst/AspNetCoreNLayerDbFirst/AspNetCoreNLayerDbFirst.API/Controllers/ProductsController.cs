﻿using AspNetCoreNLayerDbFirst.Core.Entities.Concrete;
using AspNetCoreNLayerDbFirst.Core.Services.Dapper;
using AspNetCoreNLayerDbFirst.Core.Services.MongoDB;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace AspNetCoreNLayerDbFirst.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private IProductDapperService _productDapperService;
        private readonly ILogMongoService _logService;

        public ProductsController(IProductDapperService productDapperService, ILogMongoService logService)
        {
            _productDapperService = productDapperService;
            _logService = logService;
        }

        // GET: api/Products
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Product>>> GetProducts()
        {
            string sql = "SELECT * FROM Products";
            var result = await _productDapperService.QueryAsync(sql);
            return Ok(result.ToList());
        }

        // GET: api/Products/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Product>> GetProduct(int id)
        {
            string sql = $"SELECT * FROM Products WHERE Id={id}";
            var result = await _productDapperService.QuerySingleAsync(sql);

            if (result == null)
            {
                return NotFound();
            }
            return Ok(result);
        }

        // PUT: api/Products/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutProduct(int id, Product product)
        {
            if (id != product.Id)
            {
                return BadRequest();
            }

            string currentProductSQL = $"SELECT * FROM Products WHERE Id={id}";
            var currentProduct = await _productDapperService.QuerySingleAsync(currentProductSQL);

            var log = _logService.UpdateLog(this.GetType().Name, ControllerContext.ActionDescriptor.ActionName, currentProduct, product);

            string sql = @"UPDATE Products SET Name=@Name, Stock=@Stock, Price=@Price, IsDeleted=@IsDeleted, CategoryId=@CategoryId WHERE Id=@Id";
            object param = new
            {
                Name = product.Name,
                Stock = product.Stock,
                Price = product.Price,
                IsDeleted = product.IsDeleted,
                CategoryId = product.CategoryId,
                Id = id
            };

            try
            {
                await _productDapperService.ExecuteAsync(sql, param);
                await _logService.AddAsync(log);
                return Ok();
            }
            catch (System.Exception e)
            {
                if (!ProductExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
        }

        // POST: api/Products
        [HttpPost]
        public async Task<ActionResult<Product>> PostProduct(Product product)
        {
            string sql = @"INSERT INTO Products ([Id], [Name], [Stock], [Price], [IsDeleted], [CategoryId]) VALUES (@Id, @Name, @Stock, @Price, @IsDeleted, @CategoryId)";
            object param = new
            {
                Id = product.Id,
                Name = product.Name,
                Stock = product.Stock,
                Price = product.Price,
                IsDeleted = product.IsDeleted,
                CategoryId = product.CategoryId,
            };

            var log = _logService.CreateLog(this.GetType().Name, ControllerContext.ActionDescriptor.ActionName, product);

            await _productDapperService.ExecuteAsync(sql, param);
            await _logService.AddAsync(log);
            return Ok();
        }

        // DELETE: api/Products/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Product>> DeleteProduct(int id)
        {
            string productSQL = $"SELECT * FROM Products WHERE Id={id}";
            var product = await _productDapperService.QuerySingleAsync(productSQL);

            var log = _logService.CreateLog(this.GetType().Name, ControllerContext.ActionDescriptor.ActionName, product);

            string sql = $"DELETE FROM Products WHERE Id={id}";

            await _productDapperService.ExecuteAsync(sql);
            await _logService.AddAsync(log);

            return Ok();
        }

        private bool ProductExists(int id)
        {
            string sql = $"SELECT * FROM Products WHERE Id={id}";
            var result = _productDapperService.QuerySingle(sql);

            if (result == null)
            {
                return false;
            }
            return true;
        }
    }
}
