﻿using AspNetCoreNLayerDbFirst.API.Dtos;
using AspNetCoreNLayerDbFirst.Core.Entities.Concrete;
using AutoMapper;

namespace AspNetCoreNLayerDbFirst.API.Mappings
{
    public class MapProfile : Profile
    {
        public MapProfile()
        {
            CreateMap<Category, CategoryDto>().ReverseMap();
            CreateMap<CategoryDto, Category>().ReverseMap();

            CreateMap<CategoryWithProductDto, Category>().ReverseMap();
            CreateMap<Category, CategoryWithProductDto>().ReverseMap();

            CreateMap<ProductDto, Product>().ReverseMap();
            CreateMap<Product, ProductDto>().ReverseMap();
        }
    }
}
