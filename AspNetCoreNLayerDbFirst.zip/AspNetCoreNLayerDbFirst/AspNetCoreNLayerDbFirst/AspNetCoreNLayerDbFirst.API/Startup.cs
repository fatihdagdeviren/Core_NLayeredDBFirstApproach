using AspNetCoreNLayerDbFirst.API.Extensions;
using AspNetCoreNLayerDbFirst.API.Filters;
using AspNetCoreNLayerDbFirst.Business.Services.Dapper;
using AspNetCoreNLayerDbFirst.Business.Services.EntityFramework;
using AspNetCoreNLayerDbFirst.Business.Services.MongoDB;
using AspNetCoreNLayerDbFirst.Business.Services.Redis;
using AspNetCoreNLayerDbFirst.Core.Repositories.Dapper;
using AspNetCoreNLayerDbFirst.Core.Repositories.EntityFramework;
using AspNetCoreNLayerDbFirst.Core.Services.Dapper;
using AspNetCoreNLayerDbFirst.Core.Services.EntityFramework;
using AspNetCoreNLayerDbFirst.Core.Services.MongoDB;
using AspNetCoreNLayerDbFirst.Core.Services.Redis;
using AspNetCoreNLayerDbFirst.Core.UnitOfWorks.Dapper;
using AspNetCoreNLayerDbFirst.Core.UnitOfWorks.EntityFramework;
using AspNetCoreNLayerDbFirst.Data.Repositories.Dapper;
using AspNetCoreNLayerDbFirst.Data.Repositories.EntityFramework;
using AspNetCoreNLayerDbFirst.Data.Repositories.EntityFramework.Contexts;
using AspNetCoreNLayerDbFirst.Data.Repositories.MongoDB;
using AspNetCoreNLayerDbFirst.Data.UnitOfWorks.Dapper;
using AspNetCoreNLayerDbFirst.Data.UnitOfWorks.EntityFramework;
using AutoMapper;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;

namespace AspNetCoreNLayerDbFirst.API
{
    public class Startup
    {
        public IConfiguration Configuration { get; set; }
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();
            services.AddAutoMapper(typeof(Startup)); 
            services.AddScoped<NotFoundFilter>();
            services.AddScoped<AuthFilter>();

            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();


            services.Configure<MongoDatabaseSettings>(Configuration.GetSection(nameof(MongoDB)));
            services.AddSingleton<IMongoDatabaseSettings>(provider => provider.GetRequiredService<IOptions<MongoDatabaseSettings>>().Value);
            services.AddScoped<ILogMongoService, LogMongoService>();


            services.AddSingleton<RedisService>();
            services.AddSingleton<IRedisService, RedisService>();

            services.AddScoped(typeof(IEntityRepository<>), typeof(EntityRepository<>));
            services.AddScoped(typeof(IEntityService<>), typeof(EntityService<>));
            services.AddScoped<IProductEntityService, ProductEntityService>();
            services.AddScoped<ICategoryEntityService, CategoryEntityService>();
            services.AddScoped<IEfUnitOfWork, EfUnitOfWork>();

            services.AddScoped(typeof(IDapperRepository<>), typeof(DapperRepository<>));
            services.AddScoped(typeof(IDapperService<>), typeof(DapperService<>));
            services.AddScoped<IProductDapperService, ProductDapperService>();
            services.AddScoped<IUserDapperService, UserDapperService>();
            services.AddScoped<IUserDapperService, UserDapperService>();
            services.AddScoped<IDapperUnitOfWork, DapperUnitOfWork>();

            services.AddDbContext<EntityDbContext>(options => options.UseSqlServer(Configuration.GetConnectionString("MSSQL")));
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, RedisService redis)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            redis.Connect();

            app.UseCustomException();         
            
            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
