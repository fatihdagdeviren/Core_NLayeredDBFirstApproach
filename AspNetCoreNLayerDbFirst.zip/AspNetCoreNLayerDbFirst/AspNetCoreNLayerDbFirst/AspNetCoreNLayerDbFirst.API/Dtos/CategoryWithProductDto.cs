﻿using System.Collections.Generic;

namespace AspNetCoreNLayerDbFirst.API.Dtos
{
    public class CategoryWithProductDto : CategoryDto
    {
        public IEnumerable<ProductDto> Products { get; set; }
    }
}
