﻿using System.ComponentModel.DataAnnotations;

namespace AspNetCoreNLayerDbFirst.API.Dtos
{
    public class CategoryDto
    {
        public int Id { get; set; }
        [Required]
        public string Name { get; set; }
    }
}
