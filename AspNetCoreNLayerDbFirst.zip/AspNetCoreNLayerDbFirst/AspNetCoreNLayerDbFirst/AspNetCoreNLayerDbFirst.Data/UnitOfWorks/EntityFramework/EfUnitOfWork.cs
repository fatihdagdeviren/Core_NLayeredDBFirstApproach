﻿using AspNetCoreNLayerDbFirst.Core.Repositories.EntityFramework;
using AspNetCoreNLayerDbFirst.Core.UnitOfWorks.EntityFramework;
using AspNetCoreNLayerDbFirst.Data.Repositories.EntityFramework;
using AspNetCoreNLayerDbFirst.Data.Repositories.EntityFramework.Contexts;
using System.Data;
using System.Threading.Tasks;

namespace AspNetCoreNLayerDbFirst.Data.UnitOfWorks.EntityFramework
{
    public class EfUnitOfWork : IEfUnitOfWork
    {
        private readonly EntityDbContext _appDbContext;
        private ProductEntityRepository _productRepository;
        private CategoryEntityRepository _categoryRepository;
        public IProductEntityRepository Products => _productRepository = _productRepository ?? new ProductEntityRepository(_appDbContext);

        public ICategoryEntityRepository Categories => _categoryRepository = _categoryRepository ?? new CategoryEntityRepository(_appDbContext);

        public EfUnitOfWork(EntityDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public void Commit()
        {
            _appDbContext.SaveChanges();
        }

        public async Task CommitAsync()
        {
            await _appDbContext.SaveChangesAsync();
        }
    }
}
