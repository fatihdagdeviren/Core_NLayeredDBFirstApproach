﻿using AspNetCoreNLayerDbFirst.Core.Entities.Concrete;
using AspNetCoreNLayerDbFirst.Core.Repositories.Dapper;
using Microsoft.Extensions.Configuration;

namespace AspNetCoreNLayerDbFirst.Data.Repositories.Dapper
{
    public class UserDapperRepository : DapperRepository<User>, IUserDapperRepository
    {
        public UserDapperRepository(IConfiguration configuration) : base(configuration)
        {
        }
    }
}
