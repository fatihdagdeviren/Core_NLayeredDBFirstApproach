﻿using AspNetCoreNLayerDbFirst.Core.Entities.Concrete;
using AspNetCoreNLayerDbFirst.Core.Repositories.Dapper;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace AspNetCoreNLayerDbFirst.Data.Repositories.Dapper
{
    public class ProductDapperRepository : DapperRepository<Product>, IProductDapperRepository
    {
        public ProductDapperRepository(IConfiguration configuration) : base(configuration)
        {
        }
    }
}
