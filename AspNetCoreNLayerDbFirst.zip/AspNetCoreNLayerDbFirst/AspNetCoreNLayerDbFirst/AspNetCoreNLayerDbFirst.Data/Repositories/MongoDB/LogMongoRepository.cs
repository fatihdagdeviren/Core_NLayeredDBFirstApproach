﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AspNetCoreNLayerDbFirst.Data.Repositories.MongoDB
{
    class LogMongoRepository
    {
    }
}
