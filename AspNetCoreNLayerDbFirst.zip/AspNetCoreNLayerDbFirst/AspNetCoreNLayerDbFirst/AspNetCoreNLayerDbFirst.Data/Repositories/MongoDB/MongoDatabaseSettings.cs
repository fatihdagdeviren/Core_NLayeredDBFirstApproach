﻿using AspNetCoreNLayerDbFirst.Core.Services.MongoDB;
using System;
using System.Collections.Generic;
using System.Text;

namespace AspNetCoreNLayerDbFirst.Data.Repositories.MongoDB
{
    public class MongoDatabaseSettings : IMongoDatabaseSettings
    {
        public string CollectionName { get; set; }
        public string ConnectionString { get; set; }
        public string DatabaseName { get; set; }
    }
}
