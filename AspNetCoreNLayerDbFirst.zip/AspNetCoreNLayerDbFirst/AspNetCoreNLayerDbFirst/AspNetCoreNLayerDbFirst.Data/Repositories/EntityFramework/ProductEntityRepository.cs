﻿using AspNetCoreNLayerDbFirst.Core.Entities.Concrete;
using AspNetCoreNLayerDbFirst.Core.Repositories.EntityFramework;
using AspNetCoreNLayerDbFirst.Data.Repositories.EntityFramework.Contexts;

namespace AspNetCoreNLayerDbFirst.Data.Repositories.EntityFramework
{
    public class ProductEntityRepository : EntityRepository<Product>, IProductEntityRepository
    {
        private EntityDbContext _appDbContext
        {
            get => _context as EntityDbContext;
        }
        public ProductEntityRepository(EntityDbContext context) : base(context)
        {

        }
    }
}
