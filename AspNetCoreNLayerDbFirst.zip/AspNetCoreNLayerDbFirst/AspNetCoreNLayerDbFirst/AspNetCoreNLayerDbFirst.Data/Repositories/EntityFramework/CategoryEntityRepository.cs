﻿using AspNetCoreNLayerDbFirst.Core.Entities.Concrete;
using AspNetCoreNLayerDbFirst.Core.Repositories.EntityFramework;
using AspNetCoreNLayerDbFirst.Data.Repositories.EntityFramework.Contexts;

namespace AspNetCoreNLayerDbFirst.Data.Repositories.EntityFramework
{
    public class CategoryEntityRepository : EntityRepository<Category>, ICategoryEntityRepository
    {
        private EntityDbContext _appDbContext
        {
            get => _context as EntityDbContext;
        }
        public CategoryEntityRepository(EntityDbContext context) : base(context)
        {

        }
    }
}
