﻿using AspNetCoreNLayerDbFirst.Core.Entities.Concrete;
using Microsoft.EntityFrameworkCore;

namespace AspNetCoreNLayerDbFirst.Data.Repositories.EntityFramework.Contexts
{
    public class EntityDbContext : DbContext
    {
        public EntityDbContext(DbContextOptions<EntityDbContext> options) : base(options)
        { }

        public DbSet<Product> Products { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<User> Users { get; set; }
    }
}
