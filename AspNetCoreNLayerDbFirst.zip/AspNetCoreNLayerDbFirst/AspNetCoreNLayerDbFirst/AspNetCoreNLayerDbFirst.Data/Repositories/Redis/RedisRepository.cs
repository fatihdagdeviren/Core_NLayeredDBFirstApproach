﻿using AspNetCoreNLayerDbFirst.Core.Repositories.Redis;
using Microsoft.Extensions.Configuration;
using StackExchange.Redis;

namespace AspNetCoreNLayerDbFirst.Data.Repositories.Redis
{
    public class RedisRepository : IRedisRepository
    {
        private readonly string _redisHost;
        private readonly string _redisPort;
        private ConnectionMultiplexer _connectionMultiplexer;
        public RedisRepository(IConfiguration configuration)
        {
            _redisHost = configuration["Redis:Host"];
            _redisPort = configuration["Redis:Port"];
        }
        public void Connect()
        {
            var config = $"{_redisHost}:{_redisPort}";
            _connectionMultiplexer = ConnectionMultiplexer.Connect(config);
        }
        public IDatabase GetDb(int db)
        {
            return _connectionMultiplexer.GetDatabase(db);
        }
    }
}
