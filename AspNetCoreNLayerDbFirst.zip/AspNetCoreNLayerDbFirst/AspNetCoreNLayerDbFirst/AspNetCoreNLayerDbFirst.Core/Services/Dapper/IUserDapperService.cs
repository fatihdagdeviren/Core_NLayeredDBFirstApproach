﻿using AspNetCoreNLayerDbFirst.Core.Entities.Concrete;

namespace AspNetCoreNLayerDbFirst.Core.Services.Dapper
{
    public interface IUserDapperService : IDapperService<User>
    {
    }
}
