﻿using AspNetCoreNLayerDbFirst.Core.Entities.Concrete;

namespace AspNetCoreNLayerDbFirst.Core.Services.MongoDB
{
    public interface ILogMongoService : IMongoService<Log>
    {
        Log CreateLog(string className, string operation, object entity); 
        Log UpdateLog(string className, string operation, object currentEntity, object newEntity);
        string GetIPAddress();
    }
}
