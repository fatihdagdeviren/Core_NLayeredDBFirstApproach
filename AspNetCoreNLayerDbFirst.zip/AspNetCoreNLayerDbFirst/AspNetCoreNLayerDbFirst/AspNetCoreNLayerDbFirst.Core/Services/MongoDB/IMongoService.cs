﻿using MongoDB.Driver;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AspNetCoreNLayerDbFirst.Core.Services.MongoDB
{
    public interface IMongoService<TEntity> where TEntity:class
    {
        Task<List<TEntity>> GetAllAsync(FilterDefinition<TEntity> filter);
        Task<TEntity> GetByIdAsync(FilterDefinition<TEntity> filter);
        Task<TEntity> AddAsync(TEntity entity);
        Task UpdateAsync(FilterDefinition<TEntity> filter, TEntity entity);
        Task DeleteAsync(FilterDefinition<TEntity> filter);
    }
}
