﻿using AspNetCoreNLayerDbFirst.Core.Entities.Concrete;

namespace AspNetCoreNLayerDbFirst.Core.Services.EntityFramework
{
    public interface IProductEntityService : IEntityService<Product>
    {
    }
}
