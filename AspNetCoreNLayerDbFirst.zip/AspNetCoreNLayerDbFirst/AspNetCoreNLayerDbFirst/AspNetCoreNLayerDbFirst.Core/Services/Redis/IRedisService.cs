﻿using StackExchange.Redis;

namespace AspNetCoreNLayerDbFirst.Core.Services.Redis
{
    public interface IRedisService
    {
        void Connect();
        IDatabase GetDb(int db);
    }
}
