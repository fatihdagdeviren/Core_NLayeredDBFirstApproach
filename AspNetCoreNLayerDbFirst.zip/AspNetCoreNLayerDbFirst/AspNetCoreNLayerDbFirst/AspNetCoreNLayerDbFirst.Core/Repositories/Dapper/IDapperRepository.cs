﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace AspNetCoreNLayerDbFirst.Core.Repositories.Dapper
{
    public interface IDapperRepository<TEntity> where TEntity : class
    {
        void Execute(string sql, object param = null);
        Task ExecuteAsync(string sql, object param = null);
        IEnumerable<TEntity> Query(string sql, object param = null);
        Task<IEnumerable<TEntity>> QueryAsync(string sql, object param = null);
        TEntity QueryFirst(string sql, object param = null);
        Task<TEntity> QueryFirstAsync(string sql, object param = null);
        TEntity QueryFirstOrDefault(string sql, object param = null);
        Task<TEntity> QueryFirstOrDefaultAsync(string sql, object param = null);
        TEntity QuerySingle(string sql, object param = null);
        Task<TEntity> QuerySingleAsync(string sql, object param = null);
        TEntity QuerySingleOrDefault(string sql, object param = null);
        Task<TEntity> QuerySingleOrDefaultAsync(string sql, object param = null);
    }
}
