﻿using AspNetCoreNLayerDbFirst.Core.Entities.Concrete;

namespace AspNetCoreNLayerDbFirst.Core.Repositories.Dapper
{
    public interface IProductDapperRepository : IDapperRepository<Product>
    {
    }
}
