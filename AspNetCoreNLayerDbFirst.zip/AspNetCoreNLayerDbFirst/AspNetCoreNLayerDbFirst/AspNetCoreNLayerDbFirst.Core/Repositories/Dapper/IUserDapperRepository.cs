﻿using AspNetCoreNLayerDbFirst.Core.Entities.Concrete;

namespace AspNetCoreNLayerDbFirst.Core.Repositories.Dapper
{
    public interface IUserDapperRepository : IDapperRepository<User>
    {
    }
}
