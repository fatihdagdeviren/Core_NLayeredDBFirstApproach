﻿using AspNetCoreNLayerDbFirst.Core.Entities.Concrete;

namespace AspNetCoreNLayerDbFirst.Core.Repositories.EntityFramework
{
    public interface ICategoryEntityRepository : IEntityRepository<Category>
    {
    }
}
