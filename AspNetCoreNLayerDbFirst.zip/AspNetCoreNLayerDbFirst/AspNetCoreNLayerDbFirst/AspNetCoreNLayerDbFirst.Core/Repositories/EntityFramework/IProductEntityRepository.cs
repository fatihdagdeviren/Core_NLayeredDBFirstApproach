﻿using AspNetCoreNLayerDbFirst.Core.Entities.Concrete;

namespace AspNetCoreNLayerDbFirst.Core.Repositories.EntityFramework
{
    public interface IProductEntityRepository : IEntityRepository<Product>
    {
    }
}
