﻿using AspNetCoreNLayerDbFirst.Core.Entities.Concrete;

namespace AspNetCoreNLayerDbFirst.Core.Repositories.MongoDB
{
    public interface ILogMongoRepository : IMongoRepository<Log>
    {
    }
}
