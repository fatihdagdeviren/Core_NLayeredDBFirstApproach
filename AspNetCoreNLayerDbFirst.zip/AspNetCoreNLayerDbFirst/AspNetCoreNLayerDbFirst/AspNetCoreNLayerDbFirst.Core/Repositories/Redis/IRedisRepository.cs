﻿using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Text;

namespace AspNetCoreNLayerDbFirst.Core.Repositories.Redis
{
    public interface IRedisRepository
    {
        void Connect();
        IDatabase GetDb(int db);
    }
}
