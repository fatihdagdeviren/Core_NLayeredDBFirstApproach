﻿using System;
using System.Data;

namespace AspNetCoreNLayerDbFirst.Core.UnitOfWorks.Dapper
{
    public interface IDapperUnitOfWork : IDisposable
    {
        IDbConnection Connection { get; }
        IDbTransaction Transaction { get; }
        IsolationLevel IsolationLevel { get; }
        void Commit();
    }
}
