﻿using AspNetCoreNLayerDbFirst.Core.Repositories.EntityFramework;
using System.Threading.Tasks;

namespace AspNetCoreNLayerDbFirst.Core.UnitOfWorks.EntityFramework
{
    public interface IEfUnitOfWork
    {
        IProductEntityRepository Products { get; }
        ICategoryEntityRepository Categories { get; }
        Task CommitAsync();
        void Commit();
    }
}
