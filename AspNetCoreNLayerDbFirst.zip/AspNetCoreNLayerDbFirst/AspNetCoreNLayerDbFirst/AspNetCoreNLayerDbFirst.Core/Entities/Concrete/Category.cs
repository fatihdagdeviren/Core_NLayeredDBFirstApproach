﻿using AspNetCoreNLayerDbFirst.Core.Entities.Abstract;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace AspNetCoreNLayerDbFirst.Core.Entities.Concrete
{
    public class Category : IEntity
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
        public bool IsDeleted { get; set; }
    }
}
