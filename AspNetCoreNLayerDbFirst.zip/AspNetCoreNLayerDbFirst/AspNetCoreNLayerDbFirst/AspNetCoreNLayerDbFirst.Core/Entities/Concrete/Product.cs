﻿using AspNetCoreNLayerDbFirst.Core.Entities.Abstract;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AspNetCoreNLayerDbFirst.Core.Entities.Concrete
{
    public class Product : IEntity
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
        public int Stock { get; set; }
        public decimal Price { get; set; }
        public byte IsDeleted { get; set; }
        public int CategoryId { get; set; }
    }
}
