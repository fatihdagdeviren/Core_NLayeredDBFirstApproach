﻿using AspNetCoreNLayerDbFirst.Core.Entities.Abstract;
using System.ComponentModel.DataAnnotations;

namespace AspNetCoreNLayerDbFirst.Core.Entities.Concrete
{
    public class User : IEntity
    {
        [Key]
        public string KullaniciID { get; set; }
        public string KullaniciAdi { get; set; }
        public string AdSoyad { get; set; }
        public string Aktif { get; set; }
        public string OturumNo { get; set; }
    }
}
