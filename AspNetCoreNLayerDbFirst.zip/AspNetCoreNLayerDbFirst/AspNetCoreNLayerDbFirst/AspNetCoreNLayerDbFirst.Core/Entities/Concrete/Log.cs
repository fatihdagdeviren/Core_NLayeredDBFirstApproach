﻿using AspNetCoreNLayerDbFirst.Core.Entities.Abstract;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;

namespace AspNetCoreNLayerDbFirst.Core.Entities.Concrete
{
    public class Log : IEntity
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }
        public object CurrentEntity { get; set; }
        public object NewEntity { get; set; }
        public DateTime LoggingDate { get; set; }
        public string IP { get; set; }
        public string Operation { get; set; }
        public string ClassName { get; set; }
    }
}
