﻿namespace AspNetCoreNLayerDbFirst.Core.Entities.Abstract
{
    public interface IEntity
    {
    }
}
