﻿using AspNetCoreNLayerDbFirst.Core.Repositories.MongoDB;
using AspNetCoreNLayerDbFirst.Core.Services.MongoDB;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AspNetCoreNLayerDbFirst.Business.Services.MongoDB
{
    public class MongoService<TEntity> : IMongoService<TEntity> where TEntity : class
    {
        private readonly IMongoCollection<TEntity> _entities;

        public MongoService(IMongoDatabaseSettings settings)
        {
            var client = new MongoClient(settings.ConnectionString);
            var database = client.GetDatabase(settings.DatabaseName);
            _entities = database.GetCollection<TEntity>(settings.CollectionName);
        }

        public async Task<List<TEntity>> GetAllAsync(FilterDefinition<TEntity> filter)
        {
            return await _entities.Find(filter).ToListAsync();
        }
        public async Task<TEntity> GetByIdAsync(FilterDefinition<TEntity> filter)
        {
            return await _entities.Find(filter).FirstOrDefaultAsync();
        }
        public async Task<TEntity> AddAsync(TEntity entity)
        {
            await _entities.InsertOneAsync(entity);
            return entity;
        }
        public async Task UpdateAsync(FilterDefinition<TEntity> filter, TEntity entity)
        {
            await _entities.ReplaceOneAsync(filter, entity);
        }
        public async Task DeleteAsync(FilterDefinition<TEntity> filter)
        {
            await _entities.DeleteOneAsync(filter);
        }
    }
}
