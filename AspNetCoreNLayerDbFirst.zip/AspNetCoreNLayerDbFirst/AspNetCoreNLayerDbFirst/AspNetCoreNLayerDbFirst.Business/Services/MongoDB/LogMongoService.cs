﻿using AspNetCoreNLayerDbFirst.Core.Entities.Concrete;
using AspNetCoreNLayerDbFirst.Core.Services.MongoDB;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace AspNetCoreNLayerDbFirst.Business.Services.MongoDB
{
    public class LogMongoService : MongoService<Log>, ILogMongoService
    {
        public LogMongoService(IMongoDatabaseSettings settings) : base(settings)
        {

        }

        public Log CreateLog(string className, string operation, object entity)
        {
            Log log = new Log
            {
                ClassName = className,
                NewEntity = entity,
                IP = GetIPAddress(),
                LoggingDate = DateTime.Now,
                Operation = operation
            };
            return log;
        }

        public Log UpdateLog(string className, string operation, object currentEntity, object newEntity)
        {
            Log log = new Log
            {
                ClassName = className,
                CurrentEntity = currentEntity,
                NewEntity = newEntity,
                IP = GetIPAddress(),
                LoggingDate = DateTime.Now,
                Operation = operation
            };
            return log;
        }

        public string GetIPAddress()
        {
            StringBuilder sb = new StringBuilder();
            String strHostName = string.Empty;
            strHostName = Dns.GetHostName();
            IPHostEntry ipHostEntry = Dns.GetHostEntry(strHostName);
            IPAddress[] address = ipHostEntry.AddressList;
            return address[0].ToString();
        }
    }
}
