﻿using AspNetCoreNLayerDbFirst.Core.Entities.Concrete;
using AspNetCoreNLayerDbFirst.Core.Repositories.Dapper;
using AspNetCoreNLayerDbFirst.Core.Services.Dapper;
using AspNetCoreNLayerDbFirst.Core.UnitOfWorks.Dapper;
using System;
using System.Collections.Generic;
using System.Text;

namespace AspNetCoreNLayerDbFirst.Business.Services.Dapper
{
    public class ProductDapperService : DapperService<Product>, IProductDapperService
    {
        public ProductDapperService(IDapperUnitOfWork uow, IDapperRepository<Product> dapperRepository) : base(uow, dapperRepository)
        {
        }
    }
}
