﻿using AspNetCoreNLayerDbFirst.Core.Entities.Concrete;
using AspNetCoreNLayerDbFirst.Core.Repositories.Dapper;
using AspNetCoreNLayerDbFirst.Core.Services.Dapper;
using AspNetCoreNLayerDbFirst.Core.UnitOfWorks.Dapper;
using System;
using System.Collections.Generic;
using System.Text;

namespace AspNetCoreNLayerDbFirst.Business.Services.Dapper
{
    public class UserDapperService : DapperService<User>, IUserDapperService
    {
        public UserDapperService(IDapperUnitOfWork uow, IDapperRepository<User> dapperRepository) : base(uow, dapperRepository)
        {
        }
    }
}
