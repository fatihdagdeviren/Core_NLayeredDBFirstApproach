﻿using AspNetCoreNLayerDbFirst.Core.Services.Redis;
using Microsoft.Extensions.Configuration;
using StackExchange.Redis;

namespace AspNetCoreNLayerDbFirst.Business.Services.Redis
{
    public class RedisService : IRedisService
    {
        private readonly string _redisHost;
        private readonly string _redisPort;
        private ConnectionMultiplexer _connectionMultiplexer;
        public RedisService(IConfiguration configuration)
        {
            _redisHost = configuration["Redis:Host"];
            _redisPort = configuration["Redis:Port"];
        }
        public void Connect()
        {
            var config = $"{_redisHost}:{_redisPort}";
            _connectionMultiplexer = ConnectionMultiplexer.Connect(config);
        }

        public IDatabase GetDb(int db)
        {
            return _connectionMultiplexer.GetDatabase(db);
        }
    }
}
