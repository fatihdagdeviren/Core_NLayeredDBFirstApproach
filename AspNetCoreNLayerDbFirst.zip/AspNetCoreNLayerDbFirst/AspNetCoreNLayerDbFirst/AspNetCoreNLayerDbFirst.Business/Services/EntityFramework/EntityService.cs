﻿using AspNetCoreNLayerDbFirst.Core.Repositories.EntityFramework;
using AspNetCoreNLayerDbFirst.Core.Services.EntityFramework;
using AspNetCoreNLayerDbFirst.Core.UnitOfWorks.EntityFramework;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace AspNetCoreNLayerDbFirst.Business.Services.EntityFramework
{
    public class EntityService<TEntity> : IEntityService<TEntity> where TEntity : class
    {
        public readonly IEfUnitOfWork _unitOfWork;
        private readonly IEntityRepository<TEntity> _entityRepository;
        public EntityService(IEfUnitOfWork unitOfWork, IEntityRepository<TEntity> entityRepository)
        {
            _unitOfWork = unitOfWork;
            _entityRepository = entityRepository;
        }
        public async Task<TEntity> GetByIdAsync(int id)
        {
            return await _entityRepository.GetByIdAsync(id);
        }
        public async Task<IEnumerable<TEntity>> GetAllAsync()
        {
            return await _entityRepository.GetAllAsync();
        }
        public async Task<TEntity> AddAsync(TEntity entity)
        {
            await _entityRepository.AddAsync(entity);
            await _unitOfWork.CommitAsync();
            return entity;
        }
        public async Task<IEnumerable<TEntity>> AddRangeAsync(IEnumerable<TEntity> entities)
        {
            await _entityRepository.AddRangeAsync(entities);
            await _unitOfWork.CommitAsync();
            return entities;
        }
        public async Task<TEntity> SingleOrDefaultAsync(Expression<Func<TEntity, bool>> predicate)
        {
            return await _entityRepository.SingleOrDefaultAsync(predicate);
        }
        public async Task<IEnumerable<TEntity>> Where(Expression<Func<TEntity, bool>> predicate)
        {
            return await _entityRepository.Where(predicate);
        }
        public TEntity Update(TEntity entity)
        {
            TEntity updateEntity = _entityRepository.Update(entity);
            _unitOfWork.Commit();
            return updateEntity;
        }
        public void Remove(TEntity entity)
        {
            _entityRepository.Remove(entity);
            _unitOfWork.Commit();
        }
        public void RemoveRange(IEnumerable<TEntity> entities)
        {
            _entityRepository.RemoveRange(entities);
            _unitOfWork.Commit();
        }
    }
}
