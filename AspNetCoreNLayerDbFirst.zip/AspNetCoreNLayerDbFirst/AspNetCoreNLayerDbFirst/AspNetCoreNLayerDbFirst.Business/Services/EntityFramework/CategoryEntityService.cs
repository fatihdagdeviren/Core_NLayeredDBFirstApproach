﻿using AspNetCoreNLayerDbFirst.Core.Entities.Concrete;
using AspNetCoreNLayerDbFirst.Core.Repositories.EntityFramework;
using AspNetCoreNLayerDbFirst.Core.Services.EntityFramework;
using AspNetCoreNLayerDbFirst.Core.UnitOfWorks.EntityFramework;

namespace AspNetCoreNLayerDbFirst.Business.Services.EntityFramework
{
    public class CategoryEntityService : EntityService<Category>, ICategoryEntityService
    {
        public CategoryEntityService(IEfUnitOfWork unitOfWork, IEntityRepository<Category> repository) : base(unitOfWork, repository)
        {

        }
    }
}
