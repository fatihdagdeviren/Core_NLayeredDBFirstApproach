﻿using AspNetCoreNLayerDbFirst.Core.Entities.Concrete;
using AspNetCoreNLayerDbFirst.Core.Repositories.EntityFramework;
using AspNetCoreNLayerDbFirst.Core.Services.EntityFramework;
using AspNetCoreNLayerDbFirst.Core.UnitOfWorks.EntityFramework;

namespace AspNetCoreNLayerDbFirst.Business.Services.EntityFramework
{
    public class ProductEntityService : EntityService<Product>, IProductEntityService
    {
        public ProductEntityService(IEfUnitOfWork unitOfWork, IEntityRepository<Product> repository) : base(unitOfWork, repository)
        {

        }
    }
}
